scoreboard objectives add recipebook trigger
