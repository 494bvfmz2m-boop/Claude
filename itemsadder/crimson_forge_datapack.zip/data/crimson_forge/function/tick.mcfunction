scoreboard players enable @a recipebook
execute as @a[scores={recipebook=1..}] run function crimson_forge:give_book
scoreboard players set @a[scores={recipebook=1..}] recipebook 0
